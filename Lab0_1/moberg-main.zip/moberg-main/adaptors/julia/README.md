# MobergIO.jl

A library for connecting to various input/output libraries with a common interface.

You need a local configuration and installation of Moberg for this package to work properly, see: [github.com/ControlLTH/moberg](https://github.com/ControlLTH/moberg).
